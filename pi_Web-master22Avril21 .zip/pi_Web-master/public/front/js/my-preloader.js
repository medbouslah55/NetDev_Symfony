window.onload = function() {
    document.querySelector('.preloader').style.display = "none"; 
    document.querySelector('.page').style.opacity = "1"; 
}
